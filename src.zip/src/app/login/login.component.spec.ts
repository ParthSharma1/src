import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DebugElement } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([]),
        FormsModule,
        ReactiveFormsModule
      ],
      declarations: [ LoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('user should be null',()=>{
    expect(component.userl).toBeNull;
  });
  it('username should be null',()=>{
    expect(component.userl.username).toBeNull;
  });
  it('password should be null',()=>{
    expect(component.userl.password).toBeNull;
  });
  it('Should call the loginUser method', async(()=>{
    fixture.detectChanges();
    spyOn(component, 'loginUser');
    el =  fixture.nativeElement;
    el.click;
    expect(component.loginUser).toHaveBeenCalledTimes(0);
  }));
});
