export class user {

 
    id:number;
    password: string;
    
    email: string;
    username: string;
    profilepicture: string;
     
     
     }