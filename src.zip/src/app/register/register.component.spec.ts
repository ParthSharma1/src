import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterComponent } from './register.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { user } from '../user.model';
import { By } from 'protractor';
import { DebugElement } from '@angular/core';

describe('RegisterComponent', () => {
  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        FormsModule,
        RouterTestingModule.withRoutes([]),
        ReactiveFormsModule
      ],
      declarations: [ RegisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
    
    fixture.detectChanges();
  });
it('user should be null',()=>{
  expect(component.user).toBeNull;
});
it('username should be null',()=>{
  expect(component.username).toBeNull;
});
it('password should be null',()=>{
  expect(component.password).toBeNull;
});
it('repeat password should be null',()=>{
  expect(component.repeatpassword).toBeNull;
});
it('email should be null',()=>{
  expect(component.email).toBeNull;
});
it('Should call the onFormSubmit method', async(()=>{
  fixture.detectChanges();
  spyOn(component, 'onFormSubmit');
  el =  fixture.nativeElement;
  el.click;
  expect(component.onFormSubmit).toHaveBeenCalledTimes(0);
}));
  
});
