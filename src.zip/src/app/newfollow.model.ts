export class newfollow {

 
    
followid:number;
    followerid:number;
    status:String;
   
     
     
     }