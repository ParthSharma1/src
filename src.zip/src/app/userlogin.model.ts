export class userlogin {

 
    username: string;

  
    password: string;
    
 
     
     
     }