import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mymedia-details',
  templateUrl: './mymedia-details.component.html',
  styleUrls: ['./mymedia-details.component.scss']
})
export class MymediaDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
