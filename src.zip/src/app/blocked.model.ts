export class blocked {

    id:number;
    username:String;
    blockedname:String;


     }