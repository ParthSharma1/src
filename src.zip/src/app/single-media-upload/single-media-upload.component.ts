import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { user } from '../user.model';
import { Router } from '@angular/router';
@Component({
  selector: 'app-single-media-upload',
  templateUrl: './single-media-upload.component.html',
  styleUrls: ['./single-media-upload.component.scss']
})
export class SingleMediaUploadComponent implements OnInit {
  userinfo1: user=new user();
  userinfo2: user=new user();
  name: String;
  constructor(private router: Router,private httpClient: HttpClient) { }

  ngOnInit() {
    
    if (localStorage.getItem("userinfo") === null) {
      this.router.navigate(['']);
      
       
    }

    this.userinfo2 = JSON.parse(localStorage.getItem('userinfo'));
    this.name=this.userinfo2.username;
    console.log(name);
    

  }
  title = 'ImageUploaderFrontEnd';

  public selectedFile;
  public event1;
  imgURL: any;
  receivedImageData: any;
  base64Data: any;
  convertedImage: any;

  public  onFileChanged(event) {
    console.log(event);
    this.selectedFile = event.target.files[0];

    // Below part is used to display the selected image
    let reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event2) => {
      this.imgURL = reader.result;
  };

 }


 // This part is for uploading
 onUpload() {


  const uploadData = new FormData();
  uploadData.append('imagename', this.selectedFile.name);
  this.userinfo1 = JSON.parse(localStorage.getItem('userinfo'));
uploadData.append('username',this.userinfo1.username);

  this.httpClient.post('http://localhost:4200/check/upload', uploadData)
  .subscribe(
              
            );
          
            this.router.navigate(['s2']);



 }
}